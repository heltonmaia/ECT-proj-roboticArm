
- Place the latest hand segmentation weight file here in this directory.

- Also place the latest audio classification model file here in this directory.


Download link to the latest hand segmentation weight file:
https://github.com/heltonmaia/ECT-proj-roboticArm/tree/main/weights


Download link to the latest audio classification model file:
